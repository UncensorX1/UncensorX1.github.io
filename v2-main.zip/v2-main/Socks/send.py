import os   

os.system('python Socks/tel/1.py && python Socks/tel/2.py')