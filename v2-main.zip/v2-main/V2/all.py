import os   

os.system('python V2/from64/start.py')
os.system('python V2/fromsite/start.py')
os.system('python V2/fromtele/1.py')

os.system('python V2/merge/1.py && python V2/merge/2.py && python V2/merge/3.py')
os.system('python V2/seprate/start.py')

os.system('python V2/name/ssn.py')
os.system('python V2/name/ssrn1.py && python V2/name/ssrn2.py && python V2/name/ssrn3.py && python V2/name/ssrn4.py')
os.system('python V2/name/tron.py')
os.system('python V2/name/vln.py')
os.system('python V2/name/tuname.py')
os.system('python V2/name/hy2name.py')
os.system('python V2/name/hy.py')
os.system('python V2/name/vmen1.py && python V2/name/vmen2.py && python V2/name/vmen3.py && python V2/name/vmen4.py && python V2/name/vmen5.py && python V2/name/vmen6.py && python V2/name/vmen7.py')
os.system('python V2/name/rem.py')


os.system('python V2/dup/dup.py')
os.system('python V2/dup/rem.py && python V2/dup/rem2.py')
