import os   

os.system('python Mtproto/tel/1.py && python Mtproto/tel/2.py')
